# === ORCHESTRATOR LAUNCHER ===

Write-Host "`n" ("=" * 80) -ForegroundColor Cyan
Write-Host "  🤖 OTOKODLAMA ORCHESTRATOR" -ForegroundColor Cyan
Write-Host ("=" * 80) -ForegroundColor Cyan

Write-Host "`nInitializing..." -ForegroundColor Yellow

# Check dependencies
$checks = @(
    @{Name="Node.js"; Command="node --version"},
    @{Name="Playwright"; Command="npx playwright --version"},
    @{Name="Python"; Command="python --version"}
)

foreach($check in $checks){
    try {
        $result = Invoke-Expression $check.Command 2>&1
        Write-Host "  ✓ $($check.Name): $result" -ForegroundColor Green
    } catch {
        Write-Host "  ✗ $($check.Name): NOT FOUND" -ForegroundColor Red
        exit 1
    }
}

Write-Host "`nStarting orchestrator..." -ForegroundColor Cyan

# Run Python orchestrator
python _otokodlama\orchestrator.py
