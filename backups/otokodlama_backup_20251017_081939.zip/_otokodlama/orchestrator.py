import os
import json
import subprocess
import sys
import shutil
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).parent
STATE_FILE = BASE_DIR / "state" / "tasks.json"
LOG_DIR = BASE_DIR / "logs"
BUNDLE_DIR = BASE_DIR / "bundle"
AI_QUEUE = BASE_DIR / "ai_queue"
AI_RESPONSE_DIR = AI_QUEUE / "responses"
REPORT_DIR = BASE_DIR / "reports"

for d in [STATE_FILE.parent, LOG_DIR, BUNDLE_DIR, AI_QUEUE, AI_RESPONSE_DIR, REPORT_DIR]:
    d.mkdir(exist_ok=True)

TASKS = []
with open(BASE_DIR.parent / "_otokodlama" / "todolist.csv", 'r', encoding='utf-8') as f:
    import csv
    reader = csv.DictReader(f)
    for row in reader:
        TASKS.append({
            "id": int(row["id"]),
            "name": row["name"],
            "status": row["status"],
            "priority": row["priority"],
            "test_files": row["test_files"].split(",")
        })

MAX_ROUNDS = 2

class Orchestrator:
    def __init__(self):
        self.round = 0
        self.terminal_log = []
        self.session_start = datetime.now()
        self.round_history = []
        
    def log(self, msg, level="INFO"):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        colors = {"INFO": "\033[36m", "SUCCESS": "\033[32m", "ERROR": "\033[31m", "WARN": "\033[33m", "AI": "\033[35m"}
        color = colors.get(level, "")
        log_line = f"[{timestamp}][{level}] {msg}"
        self.terminal_log.append({"time": timestamp, "level": level, "message": msg})
        print(f"{color}{log_line}\033[0m")
    
    def run_tests(self, test_files):
        patterns = " ".join(test_files)
        self.log(f"Running {len(test_files)} test files...")
        cmd = f'npx playwright test {patterns} --reporter=json'
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        
        try:
            data = json.loads(result.stdout)
            passed = sum(1 for suite in data.get("suites", []) for spec in suite.get("suites", []) for test in spec.get("specs", []) if test.get("ok"))
            failed = sum(1 for suite in data.get("suites", []) for spec in suite.get("suites", []) for test in spec.get("specs", []) if not test.get("ok"))
            return {"passed": passed, "failed": failed, "raw": data, "stdout": result.stdout, "stderr": result.stderr}
        except:
            return {"passed": 0, "failed": 0, "raw": None, "stdout": result.stdout, "stderr": result.stderr}
    
    def create_ai_bundle(self, task, results):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        bundle_name = f"task_{task['id']}_round_{self.round}_{timestamp}"
        self.log(f"Creating AI bundle: {bundle_name}", "AI")
        bundle_path = BUNDLE_DIR / bundle_name
        bundle_path.mkdir(exist_ok=True)
        
        with open(bundle_path / "results.json", 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2)
        
        with open(bundle_path / "task.json", 'w', encoding='utf-8') as f:
            json.dump(task, f, indent=2)
        
        test_results_dir = Path("test-results")
        artifacts_count = 0
        if test_results_dir.exists():
            result_dirs = sorted(test_results_dir.glob("*/"), key=lambda x: x.stat().st_mtime, reverse=True)
            for result_dir in result_dirs[:5]:
                for artifact in result_dir.glob("*"):
                    if artifact.suffix in ['.png', '.zip', '.md', '.webm']:
                        try:
                            dest_name = f"{result_dir.name}_{artifact.name}"
                            shutil.copy(str(artifact), str(bundle_path / dest_name))
                            artifacts_count += 1
                        except:
                            pass
        
        self.log(f"Artifacts: {artifacts_count}", "AI")
        return bundle_name, artifacts_count
    
    def check_ai_response(self, bundle_name):
        response_file = AI_RESPONSE_DIR / f"{bundle_name}.json"
        if response_file.exists():
            with open(response_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return None
    
    def apply_patch(self, bundle_name, response):
        if not response.get("patch_provided"):
            return False
        
        patch_file = AI_RESPONSE_DIR / f"{bundle_name}_patch.zip"
        if not patch_file.exists():
            self.log(f"Patch not found: {patch_file}", "WARN")
            return False
        
        self.log(f"Applying patch: {patch_file.name}", "AI")
        
        import zipfile
        whitelist = ["tests/"]
        applied = 0
        
        try:
            with zipfile.ZipFile(patch_file, 'r') as zip_ref:
                for file in zip_ref.namelist():
                    if any(file.startswith(w) for w in whitelist):
                        zip_ref.extract(file, ".")
                        self.log(f"✅ EXTRACTED: {file}", "SUCCESS")
                        applied += 1
                    else:
                        self.log(f"⏭️ SKIPPED: {file} (not whitelisted)", "WARN")
            
            self.log(f"PATCH SUMMARY: {applied} applied", "SUCCESS")
            return True
        except Exception as e:
            self.log(f"Patch failed: {e}", "ERROR")
            return False
    
    def next_task(self):
        pending = [t for t in TASKS if t["status"] in ["pending", "retry"]]
        if not pending:
            return None
        return sorted(pending, key=lambda x: {"high": 0, "medium": 1, "low": 2}.get(x["priority"], 3))[0]
    
    def generate_html_report(self):
        duration = (datetime.now() - self.session_start).total_seconds()
        
        html = f'''<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTOKODLAMA - Test Raporu</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }}
        .header h1 {{
            font-size: 3em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }}
        .header p {{
            font-size: 1.2em;
            opacity: 0.9;
        }}
        .stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 40px;
            background: #f8f9fa;
        }}
        .stat-card {{
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }}
        .stat-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 8px 12px rgba(0,0,0,0.15);
        }}
        .stat-number {{
            font-size: 3em;
            font-weight: bold;
            color: #667eea;
            margin: 10px 0;
        }}
        .stat-label {{
            color: #666;
            font-size: 1.1em;
        }}
        .section {{
            padding: 40px;
        }}
        .section-title {{
            font-size: 2em;
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid #667eea;
        }}
        .timeline {{
            position: relative;
            padding-left: 40px;
        }}
        .timeline::before {{
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 3px;
            background: linear-gradient(to bottom, #667eea, #764ba2);
        }}
        .timeline-item {{
            position: relative;
            margin-bottom: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
            border-left: 4px solid #667eea;
        }}
        .timeline-item::before {{
            content: '';
            position: absolute;
            left: -47px;
            top: 20px;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background: #667eea;
            border: 3px solid white;
        }}
        .log-entry {{
            display: flex;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
        }}
        .log-time {{
            color: #999;
            margin-right: 15px;
            min-width: 180px;
        }}
        .log-level {{
            font-weight: bold;
            margin-right: 15px;
            min-width: 80px;
        }}
        .log-INFO {{ background: #e3f2fd; border-left: 4px solid #2196F3; }}
        .log-SUCCESS {{ background: #e8f5e9; border-left: 4px solid #4CAF50; }}
        .log-WARN {{ background: #fff3e0; border-left: 4px solid #FF9800; }}
        .log-ERROR {{ background: #ffebee; border-left: 4px solid #f44336; }}
        .log-AI {{ background: #f3e5f5; border-left: 4px solid #9C27B0; }}
        .log-INFO .log-level {{ color: #2196F3; }}
        .log-SUCCESS .log-level {{ color: #4CAF50; }}
        .log-WARN .log-level {{ color: #FF9800; }}
        .log-ERROR .log-level {{ color: #f44336; }}
        .log-AI .log-level {{ color: #9C27B0; }}
        .task-grid {{
            display: grid;
            gap: 20px;
            margin-top: 20px;
        }}
        .task-card {{
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-left: 5px solid #ddd;
        }}
        .task-card.done {{ border-left-color: #4CAF50; }}
        .task-card.retry {{ border-left-color: #FF9800; }}
        .task-card.pending {{ border-left-color: #2196F3; }}
        .task-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }}
        .task-name {{
            font-size: 1.3em;
            font-weight: bold;
            color: #333;
        }}
        .task-status {{
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: bold;
        }}
        .status-done {{ background: #4CAF50; color: white; }}
        .status-retry {{ background: #FF9800; color: white; }}
        .status-pending {{ background: #2196F3; color: white; }}
        .footer {{
            background: #333;
            color: white;
            padding: 30px;
            text-align: center;
        }}
        .badge {{
            display: inline-block;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.85em;
            margin: 2px;
        }}
        .badge-high {{ background: #f44336; color: white; }}
        .badge-medium {{ background: #FF9800; color: white; }}
        .badge-low {{ background: #4CAF50; color: white; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🤖 OTOKODLAMA</h1>
            <p>Otomatik Test & Kod İyileştirme Raporu</p>
            <p style="margin-top: 10px; font-size: 0.9em;">
                {self.session_start.strftime("%d.%m.%Y %H:%M:%S")} - 
                Süre: {int(duration//60)}dk {int(duration%60)}sn
            </p>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <div class="stat-label">Toplam Round</div>
                <div class="stat-number">{self.round}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Toplam Task</div>
                <div class="stat-number">{len(TASKS)}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Tamamlanan</div>
                <div class="stat-number">{sum(1 for t in TASKS if t["status"] == "done")}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Toplam Log</div>
                <div class="stat-number">{len(self.terminal_log)}</div>
            </div>
        </div>
        
        <div class="section">
            <h2 class="section-title">📋 Task Durumu</h2>
            <div class="task-grid">
'''
        
        for task in TASKS:
            status_class = task["status"]
            status_display = {"done": "✅ Tamamlandı", "retry": "⚠️ Tekrar Denenecek", "pending": "📌 Bekliyor"}.get(task["status"], task["status"])
            priority_class = task["priority"]
            
            html += f'''
                <div class="task-card {status_class}">
                    <div class="task-header">
                        <div class="task-name">[{task["id"]}] {task["name"]}</div>
                        <span class="task-status status-{status_class}">{status_display}</span>
                    </div>
                    <div>
                        <span class="badge badge-{priority_class}">Priority: {task["priority"]}</span>
                        <span class="badge" style="background: #eee; color: #333;">{len(task["test_files"])} test dosyası</span>
                    </div>
                </div>
'''
        
        html += '''
            </div>
        </div>
        
        <div class="section">
            <h2 class="section-title">📜 Terminal Logları</h2>
            <div class="timeline">
'''
        
        for log in self.terminal_log:
            html += f'''
                <div class="log-entry log-{log["level"]}">
                    <span class="log-time">{log["time"]}</span>
                    <span class="log-level">[{log["level"]}]</span>
                    <span class="log-message">{log["message"]}</span>
                </div>
'''
        
        html += f'''
            </div>
        </div>
        
        <div class="footer">
            <p><strong>OTOKODLAMA v1.0</strong></p>
            <p style="margin-top: 10px; opacity: 0.8;">
                Otomatik test, AI analiz, ve kod iyileştirme sistemi
            </p>
            <p style="margin-top: 10px; font-size: 0.9em;">
                Rapor oluşturulma: {datetime.now().strftime("%d.%m.%Y %H:%M:%S")}
            </p>
        </div>
    </div>
</body>
</html>
'''
        
        report_file = REPORT_DIR / "final_report.html"
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(html)
        
        self.log(f"📊 HTML Report: {report_file}", "SUCCESS")
        return report_file
    
    def run(self):
        print("\n" + "="*80)
        print("  🤖 OTOKODLAMA - GRAND FINALE")
        print("="*80 + "\n")
        
        while self.round < MAX_ROUNDS:
            self.round += 1
            self.log(f"=== ROUND {self.round}/{MAX_ROUNDS} ===")
            
            task = self.next_task()
            if not task:
                self.log("No pending tasks!", "SUCCESS")
                break
            
            self.log(f"Task [{task['id']}] {task['name']} (Priority: {task['priority']})")
            task["status"] = "in-progress"
            
            results = self.run_tests(task["test_files"])
            self.log(f"Results: {results['passed']} passed, {results['failed']} failed")
            
            bundle_name, artifacts = self.create_ai_bundle(task, results)
            
            # Check all AI responses for this task
            all_responses = sorted(AI_RESPONSE_DIR.glob(f"task_{task['id']}_*.json"))
            ai_response = None
            for resp_file in all_responses:
                bundle_id = resp_file.stem
                temp_response = self.check_ai_response(bundle_id)
                if temp_response:
                    ai_response = temp_response
                    self.log(f"Using response: {bundle_id}", "AI")
                    break
            
            if ai_response:
                self.log(f"Analysis: {ai_response.get('analysis', 'N/A')}", "AI")
                self.log(f"Root: {ai_response.get('root_cause', 'N/A')}", "AI")
                
                if ai_response.get("patch_provided"):
                    if self.apply_patch(bundle_id, ai_response):
                        self.log("Re-running tests after patch...", "AI")
                        results = self.run_tests(task["test_files"])
                        self.log(f"After patch: {results['passed']} passed, {results['failed']} failed")
            
            if results["failed"] == 0 and results["passed"] > 0:
                task["status"] = "done"
                self.log(f"✅ Task {task['id']} COMPLETED!", "SUCCESS")
            else:
                task["status"] = "retry"
                self.log(f"⚠️ Task {task['id']} retry needed", "WARN")
            
            print()
        
        self.log("="*60)
        self.log("🎬 GENERATING FINAL REPORT...")
        self.log("="*60)
        
        report_path = self.generate_html_report()
        
        print("\n" + "="*80)
        print("  🏁 GRAND FINALE COMPLETED")
        print("="*80)
        solved = sum(1 for t in TASKS if t["status"] == "done")
        print(f"\n📊 SUMMARY:\n  Solved: {solved}/{len(TASKS)}\n  Rounds: {self.round}")
        print(f"\n📄 HTML Report: {report_path}")
        print("\n" + "="*80)
        
        import webbrowser
        webbrowser.open(str(report_path.resolve()))

if __name__ == "__main__":
    Orchestrator().run()
