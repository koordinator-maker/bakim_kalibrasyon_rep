import sys
import json
import time
from pathlib import Path
from datetime import datetime

BUNDLE_DIR = Path("_otokodlama/bundle")
AI_QUEUE = Path("_otokodlama/ai_queue")
AI_RESPONSE = Path("_otokodlama/ai_queue/responses")

AI_QUEUE.mkdir(exist_ok=True)
AI_RESPONSE.mkdir(exist_ok=True)

def send_to_ai(bundle_path):
    """Send bundle to AI and wait for response"""
    bundle_name = bundle_path.name
    
    print(f"[AI-BRIDGE] Processing: {bundle_name}")
    
    # Read prompt
    prompt_file = bundle_path / "prompt.txt"
    if not prompt_file.exists():
        print(f"[ERROR] No prompt.txt in {bundle_name}")
        return None
    
    prompt = prompt_file.read_text(encoding='utf-8')
    
    # Create AI request
    request = {
        "id": bundle_name,
        "timestamp": datetime.now().isoformat(),
        "bundle_path": str(bundle_path),
        "prompt": prompt,
        "status": "pending"
    }
    
    # Save to queue
    queue_file = AI_QUEUE / f"{bundle_name}.json"
    with open(queue_file, 'w', encoding='utf-8') as f:
        json.dump(request, f, indent=2)
    
    print(f"[AI-BRIDGE] Request queued: {queue_file}")
    print(f"[AI-BRIDGE] Bundle location: {bundle_path}")
    print(f"\n{'='*80}")
    print("🤖 MANUAL AI INTERACTION NEEDED")
    print(f"{'='*80}")
    print(f"\n1. Check bundle: {bundle_path}")
    print(f"2. Review screenshots, traces, terminal.log")
    print(f"3. Create response file:")
    print(f"   {AI_RESPONSE / bundle_name}.json")
    print(f"\n   Format:")
    print("""   {
     "analysis": "404 error on /admin/maintenance/equipment/add/",
     "root_cause": "backend",
     "patch_provided": false,
     "report": "Equipment model not registered in admin"
   }""")
    print(f"\n4. Orchestrator will auto-detect response and continue")
    print(f"\n{'='*80}\n")
    
    # Check for existing response
    response_file = AI_RESPONSE / f"{bundle_name}.json"
    if response_file.exists():
        print(f"[AI-BRIDGE] Response found: {response_file}")
        with open(response_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    return None

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python ai_bridge.py <bundle_name>")
        sys.exit(1)
    
    bundle_name = sys.argv[1]
    bundle_path = BUNDLE_DIR / bundle_name
    
    if not bundle_path.exists():
        print(f"[ERROR] Bundle not found: {bundle_path}")
        sys.exit(1)
    
    response = send_to_ai(bundle_path)
    
    if response:
        print(f"[SUCCESS] AI response received!")
        print(json.dumps(response, indent=2))
    else:
        print(f"[WAITING] No response yet. Check queue later.")
